_FOO = 4
// <- @constant
__A__ = 2
// <- @constant
_ = 2
// <- @variable
A_B_C = 4
// <- @constant
_1 = 1
// <- @variable

const A = 2
//    ^ @constant

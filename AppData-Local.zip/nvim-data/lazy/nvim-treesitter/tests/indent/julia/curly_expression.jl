function test(a::Union{Number,
                       String,
                       Nothing},
              b::Number)
end

function test(
    a::Union{
        Number,
        String,
        Nothing
    },
    b::Number
)
end

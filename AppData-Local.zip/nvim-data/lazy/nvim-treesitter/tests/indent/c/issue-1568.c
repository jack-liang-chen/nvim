int main() {
    if (1) {
        foobar();
    } else {
    }
}
